<?php
require_once "conexao.php";

// obter os dados do formulario
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

//inserir os dados na tabela usuarios 'usuario'
$sql = "INSERT INTO usuario (nome, email, senha) VALUES
('$nome', '$email', '$senha')";

if ($conn->query($sql)===TRUE){
    header("location: cadastrar_usuario_sucesso.php");
    exit();
} else {
    echo 'Erro ao cadastrar o usuário: ' .$conn->error;
}
$conn->close();



?>